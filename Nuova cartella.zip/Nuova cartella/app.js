const express = require('express')
const fs = require('fs');
const readline = require('readline');
const app = express()
   


async function processLineByLine(ourlist,n) {
  let arr = []
  const fileStream = fs.createReadStream(ourlist);

  const rl = readline.createInterface({
    input: fileStream,
    crlfDelay: Infinity
  });
  
  for await (const line of rl) {
    arr.push(line);
  }


  let numRandom =  0
  let temp = []
for (let i = 0; i < n; i++) {
    numRandom = Math.floor((Math.random() * arr.length) - 1);
    temp.push(arr[numRandom])
} 

return ` ${temp}`; 
  
}



app.get('/', async (req, res) => {

  let ris = await processLineByLine('perks.txt',3)
  let ris2 = await processLineByLine('flags.txt',2)

  let obj = {
    Perks: ris,
    flags: ris2
  }

  console.log(obj)
  res.send(obj)


})

app.listen(3000);